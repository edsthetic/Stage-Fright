/*Stage Fright
Thomas Noell, Juan Gaito, Jackie Nguyen, and Edward Gopez
Endless Runner
7/7/2021

Our creative tilt:
By making the player's actions to survive the infinite runner determine 
the purcussion of the song, the game is more dynamic as players can generate 
their own creative beat. This is connnected to the fact that in play.js, 
the punch and kick buttons are where the sound for the purcussion plays. 
This means that the player can use the slower notes at the start to have a 
bit of fun while begining to understand the game's inputs before they even hit an enemy.

On top of that, we made it a constraint to limit the player to two keys of input. 
This allows the player to understand what buttons they need to press by simply 
reading the start menu. These keys were also chosen because on English keyboards, 
these are the two keys with indents. This means that someone that may type on a 
keyboard a lot but does not really play games will have an easier experience learning 
the inputs compared to other games.*/

let config = {
    type: Phaser.CANVAS,
    width: 640,
    height: 480,
    scene: [ Menu, Play, GameOver ]
}

let game = new Phaser.Game(config);

//reserve keyboard vars
let keyF, keyJ

//set UI sizes
let borderUISize = game.config.height / 15;
let borderPadding = borderUISize / 3;
